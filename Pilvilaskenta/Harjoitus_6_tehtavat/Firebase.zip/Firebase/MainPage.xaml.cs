﻿using Google.Cloud.Firestore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Firebase
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {

        FirestoreDb db;
        public MainPage()
        {
            this.InitializeComponent();
        }



        private async void connectButton_Click_1(object sender, RoutedEventArgs e)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + @"prime-framing-302506-firebase-adminsdk-7uz6a-d67d2136e4.json";

            Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", path);

            string project = "prime-framing-302506";

            db = FirestoreDb.Create(project);

            var dialog = new MessageDialog("Connection OK");

            await dialog.ShowAsync();
        }

        private async void DataButton_Click(object sender, RoutedEventArgs e)
        {
            var bmi = Double
                .Parse(InputWeightTextBox.Text) / (Double
                .Parse(PituusInputTextBox.Text) * Double.
                Parse(PituusInputTextBox.Text));
            var weightRange = "";




            if (bmi < 18.5)
            {
                weightRange = "underweight - BMI : " + bmi;

            }
            else if (bmi < 25)
            {
                weightRange = "normal - BMI : " + bmi;

            }
            else if (bmi < 30)
            {
                weightRange = "overweight - BMI : " + bmi;
            }
            else
            {
                weightRange = "Obese BMI: " + bmi;

            }

            BMIText.Text = weightRange;

            DocumentReference documentReference = db.Collection("Persons").Document(DateTime.Now.ToString());

            Dictionary<string, object> data = new Dictionary<string, object>()
            {
                {"weight range", weightRange }
            };

            await documentReference.SetAsync(data);
            var dialog = new MessageDialog("Connection OK");

            await dialog.ShowAsync();
        }



        private async void getDocumentsButton_Click(object sender, RoutedEventArgs e)
        {


            Query allCitiesQuery = db.Collection("Persons");
            QuerySnapshot allCitiesQuerySnapshot = await allCitiesQuery.GetSnapshotAsync();
            foreach (DocumentSnapshot documentSnapshot in allCitiesQuerySnapshot.Documents)
            {
                weightTextBlock.Text += String.Format("Document data for {0}: \n"
                    , documentSnapshot.Id);
                Dictionary<string, object> city = documentSnapshot.ToDictionary();
                foreach (KeyValuePair<string, object> pair in city)
                {
                    weightTextBlock.Text += String.Format("{0}: {1} \n"
                        , pair.Key, pair.Value);
                }
                Console.WriteLine("");
            }
        }
    }

}
